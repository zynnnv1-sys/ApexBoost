# ApexBoost: Ultra Game Hub & Booster (No-Root, Shizuku API)

## 🚀 Panduan Membuka & Menjalankan di Android Studio
1. Ekstrak file ZIP ini ke folder pilihan Anda di PC / Laptop.
2. Buka **Android Studio Iguana / Jellyfish / Ladybug (Versi 2024+)**.
3. Pilih **File -> Open...** lalu arahkan ke folder ini.
4. Tunggu proses **Gradle Sync** selesai secara otomatis.
5. Hubungkan Smartphone Android (Android 8.0 ke atas, disarankan Android 11+).
6. Klik tombol **Run 'app' (Shift + F10)** untuk menginstal APK ke HP Anda.

---

## ⚡ Cara Menjalankan Shizuku Tanpa Root:
1. Instal aplikasi **Shizuku** resmi dari Play Store atau GitHub (RikkaApps/Shizuku).
2. Di HP Anda, buka **Pengaturan -> Opsi Pengembang (Developer Options)**.
3. Aktifkan **Debugging Nirkabel (Wireless Debugging)**.
4. Buka Shizuku -> Pilih "Pairing" (Masukkan kode 6 digit dari Wireless Debugging).
5. Klik "Start" di Shizuku.
6. Buka **ApexBoost** -> Berikan izin Shizuku saat diminta!
7. Selamat! Semua fitur Level ADB (ART Compiler, wm size, deep kill RAM) langsung aktif tanpa perlu PC lagi!
