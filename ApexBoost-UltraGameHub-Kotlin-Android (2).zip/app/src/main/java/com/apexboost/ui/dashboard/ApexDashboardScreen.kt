package com.apexboost.ui.dashboard

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.apexboost.ui.theme.*

@Composable
fun ApexDashboardScreen(
    viewModel: MainViewModel,
    onNavigateToGameLauncher: () -> Unit,
    onNavigateToGfxTools: () -> Unit,
    onNavigateToHudStudio: () -> Unit
) {
    val shizukuReady by viewModel.isShizukuReady.collectAsState()
    val telemetry by viewModel.telemetryData.collectAsState()
    val currentProfile by viewModel.currentProfile.collectAsState()
    val isBoosting by viewModel.isBoosting.collectAsState()

    // Cyberpunk Futuristic Dark Background
    val darkCyberBrush = Brush.verticalGradient(
        colors = listOf(Color(0xFF070913), Color(0xFF0F172A), Color(0xFF030712))
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(darkCyberBrush)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Cyberpunk Header Status
            item {
                ApexCyberHeader(
                    isShizukuActive = shizukuReady,
                    onRequestPermission = { viewModel.requestShizukuPermission() }
                )
            }

            // 2. Realtime Telemetry HUD (CPU, GPU, RAM, Temp)
            item {
                TelemetryNeonCard(telemetry = telemetry)
            }

            // 3. Instant Boost Overclock Master Button
            item {
                ApexOverclockButton(
                    isBoosting = isBoosting,
                    onBoostClick = { viewModel.executeOneTapApexBoost() }
                )
            }

            // 4. Mode Selection Matrix (Battery, Balanced, Performance, Extreme)
            item {
                ProfileSelectorMatrix(
                    selectedProfile = currentProfile,
                    onSelect = { viewModel.setBoostProfile(it) }
                )
            }

            // 5. Quick Tools Navigation Hub
            item {
                QuickToolsGrid(
                    onGfxClick = onNavigateToGfxTools,
                    onHudClick = onNavigateToHudStudio,
                    onGameHubClick = onNavigateToGameLauncher
                )
            }
        }
    }
}