package com.apexboost.core.shizuku

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

data class CommandResult(
    val exitCode: Int,
    val stdout: String,
    val stderr: String,
    val isSuccess: Boolean = exitCode == 0
)

/**
 * ShellExecutor: Menjalankan perintah ADB shell via Shizuku Process
 */
object ShellExecutor {

    /**
     * Eksekusi satu perintah shell via Shizuku.newProcess
     */
    suspend fun exec(command: String): CommandResult = withContext(Dispatchers.IO) {
        if (!ShizukuManager.checkPermission()) {
            return@withContext CommandResult(-1, "", "Shizuku permission not granted or service offline")
        }

        try {
            // Gunakan Shizuku.newProcess untuk mengeksekusi sh command
            val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)

            val stdoutBuilder = StringBuilder()
            val stderrBuilder = StringBuilder()

            // Baca output stream secara asynchronous
            val stdReader = BufferedReader(InputStreamReader(process.inputStream))
            val errReader = BufferedReader(InputStreamReader(process.errorStream))

            var line: String?
            while (stdReader.readLine().also { line = it } != null) {
                stdoutBuilder.append(line).append("\n")
            }
            while (errReader.readLine().also { line = it } != null) {
                stderrBuilder.append(line).append("\n")
            }

            val exitCode = process.waitFor()
            stdReader.close()
            errReader.close()

            CommandResult(
                exitCode = exitCode,
                stdout = stdoutBuilder.toString().trim(),
                stderr = stderrBuilder.toString().trim()
            )
        } catch (e: Exception) {
            CommandResult(
                exitCode = -1,
                stdout = "",
                stderr = "Exception: ${e.localizedMessage}"
            )
        }
    }

    /**
     * Eksekusi batch perintah dalam satu sesi shell
     */
    suspend fun execBatch(commands: List<String>): List<CommandResult> = withContext(Dispatchers.IO) {
        commands.map { cmd -> exec(cmd) }
    }
}