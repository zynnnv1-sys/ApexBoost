package com.apexboost.core.shizuku

import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuProvider
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * ApexBoost Shizuku Service Manager
 * Mengelola koneksi IPC Binder dengan Shizuku Service untuk eksekusi ADB shell.
 */
object ShizukuManager {

    private const val SHIZUKU_PERMISSION_REQUEST_CODE = 1001

    private val _isServiceRunning = MutableStateFlow(false)
    val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

    private val _hasPermission = MutableStateFlow(false)
    val hasPermission: StateFlow<Boolean> = _hasPermission.asStateFlow()

    private val _shizukuVersion = MutableStateFlow(0)
    val shizukuVersion: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

    // Listener saat binder Shizuku terhubung atau terputus
    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        _isServiceRunning.value = true
        checkPermission()
        try {
            _shizukuVersion.value = Shizuku.getVersion()
        } catch (e: Exception) {
            _shizukuVersion.value = -1
        }
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        _isServiceRunning.value = false
        _hasPermission.value = false
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == SHIZUKU_PERMISSION_REQUEST_CODE) {
                val granted = grantResult == PackageManager.PERMISSION_GRANTED
                _hasPermission.value = granted
            }
        }

    /**
     * Inisialisasi listener di Application.onCreate() atau MainActivity
     */
    fun init(context: Context) {
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(permissionResultListener)
        
        // Pengecekan awal apakah Shizuku binder sudah siap
        if (Shizuku.pingBinder()) {
            _isServiceRunning.value = true
            checkPermission()
        }
    }

    /**
     * Cek apakah izin Shizuku telah diberikan pengguna
     */
    fun checkPermission(): Boolean {
        if (!Shizuku.pingBinder()) {
            _hasPermission.value = false
            return false
        }

        return try {
            val granted = Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            _hasPermission.value = granted
            granted
        } catch (e: Exception) {
            _hasPermission.value = false
            false
        }
    }

    /**
     * Tampilkan dialog perizinan Shizuku bawaan sistem
     */
    fun requestPermission() {
        if (Shizuku.pingBinder()) {
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
            } else {
                _hasPermission.value = true
            }
        }
    }

    /**
     * Bersihkan listener saat aplikasi di-destroy
     */
    fun destroy() {
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)
    }
}