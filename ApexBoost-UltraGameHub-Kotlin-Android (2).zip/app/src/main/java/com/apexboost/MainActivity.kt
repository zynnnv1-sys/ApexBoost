package com.apexboost

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.apexboost.ui.dashboard.ApexDashboardScreen
import com.apexboost.ui.dashboard.MainViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ApexDashboardScreen(
                viewModel = viewModel,
                onNavigateToGameLauncher = { /* Navigate */ },
                onNavigateToGfxTools = { /* Navigate */ },
                onNavigateToHudStudio = { /* Navigate */ }
            )
        }
    }
}
