package com.apexboost

import android.app.Application
import com.apexboost.core.shizuku.ShizukuManager

class ApexApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Inisialisasi Shizuku Binder Lifecycle
        ShizukuManager.init(this)
    }

    override fun onTerminate() {
        super.onTerminate()
        ShizukuManager.destroy()
    }
}
