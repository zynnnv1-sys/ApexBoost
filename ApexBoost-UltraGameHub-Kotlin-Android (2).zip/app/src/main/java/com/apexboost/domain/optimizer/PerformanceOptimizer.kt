package com.apexboost.domain.optimizer

import com.apexboost.core.shizuku.CommandResult
import com.apexboost.core.shizuku.ShellExecutor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class BoostProfile {
    BATTERY_SAVER,
    BALANCED,
    PERFORMANCE,
    EXTREME_APEX
}

class PerformanceOptimizer {

    /**
     * 1. ART Compiler Speed Optimization (Dex2Oat)
     * Mengompilasi kode bytecode game ke native machine code (Ahead-Of-Time)
     * Menghilangkan stuttering & micro-lag saat rendering game.
     */
    suspend fun compileGameToSpeedMode(packageName: String): CommandResult {
        val command = "cmd package compile -m speed -f $packageName"
        return ShellExecutor.exec(command)
    }

    /**
     * 2. Deep RAM Clean: Hentikan aplikasi background non-sistem
     */
    suspend fun killBackgroundProcesses(ignoreList: List<String> = emptyList()): CommandResult {
        // Dapatkan list paket pihak ketiga yang berjalan
        val getRunningCmd = "pm list packages -3"
        val result = ShellExecutor.exec(getRunningCmd)
        
        val packages = result.stdout.lines()
            .map { it.removePrefix("package:").trim() }
            .filter { it.isNotEmpty() && !ignoreList.contains(it) }

        val killCommands = packages.map { "am force-stop $it" }
        return ShellExecutor.exec(killCommands.joinToString(" && "))
    }

    /**
     * 3. Terapkan preset performa sistem
     */
    suspend fun applyPerformanceProfile(profile: BoostProfile): List<CommandResult> = withContext(Dispatchers.IO) {
        val commands = mutableListOf<String>()

        when (profile) {
            BoostProfile.EXTREME_APEX -> {
                // Maksimalkan Hardware Acceleration & Matikan pembatas animasi
                commands.add("setprop debug.sf.hw 1")
                commands.add("setprop debug.egl.hw 1")
                commands.add("setprop debug.performance.tuning 1")
                commands.add("settings put global window_animation_scale 0.0")
                commands.add("settings put global transition_animation_scale 0.0")
                commands.add("settings put global animator_duration_scale 0.0")
                // Nonaktifkan Wi-Fi Scan Throttling untuk ping stabil
                commands.add("settings put global wifi_scan_throttle_enabled 0")
            }
            BoostProfile.PERFORMANCE -> {
                commands.add("setprop debug.sf.hw 1")
                commands.add("settings put global window_animation_scale 0.5")
                commands.add("settings put global transition_animation_scale 0.5")
                commands.add("settings put global wifi_scan_throttle_enabled 0")
            }
            BoostProfile.BALANCED -> {
                commands.add("settings put global window_animation_scale 1.0")
                commands.add("settings put global transition_animation_scale 1.0")
                commands.add("settings put global wifi_scan_throttle_enabled 1")
            }
            BoostProfile.BATTERY_SAVER -> {
                commands.add("settings put global low_power 1")
                commands.add("settings put global window_animation_scale 1.0")
            }
        }

        ShellExecutor.execBatch(commands)
    }

    /**
     * 4. Bersihkan Cache Sistem & Drop RAM Caches
     */
    suspend fun dropMemoryCaches(): CommandResult {
        return ShellExecutor.exec("echo 3 > /proc/sys/vm/drop_caches || am kill-all")
    }
}