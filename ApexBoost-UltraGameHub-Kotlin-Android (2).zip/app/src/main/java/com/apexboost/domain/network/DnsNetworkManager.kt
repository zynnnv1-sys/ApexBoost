package com.apexboost.domain.network

import com.apexboost.core.shizuku.CommandResult
import com.apexboost.core.shizuku.ShellExecutor

enum class GamingDnsProvider(val host: String, val label: String) {
    CLOUDFLARE("one.one.one.one", "Cloudflare 1.1.1.1 (Ultra Low Latency)"),
    GOOGLE("dns.google", "Google Public DNS"),
    ADGUARD("dns.adguard.com", "AdGuard (Gaming & Ad-Blocker)"),
    QUAD9("dns.quad9.net", "Quad9 Secure Gaming DNS")
}

class DnsNetworkManager {

    /**
     * Mengatur Private DNS Android ke Provider DNS Gaming
     */
    suspend fun setPrivateDns(provider: GamingDnsProvider): CommandResult {
        val cmds = listOf(
            "settings put global private_dns_mode hostname",
            "settings put global private_dns_specifier ${provider.host}"
        )
        return ShellExecutor.exec(cmds.joinToString(" && "))
    }

    /**
     * Mematikan Private DNS (kembali ke bawaan ISP/Wi-Fi)
     */
    suspend fun disablePrivateDns(): CommandResult {
        return ShellExecutor.exec("settings put global private_dns_mode off")
    }

    /**
     * Mematikan Wi-Fi Background Scanning untuk menghilangkan Ping Spike saat match
     */
    suspend fun setWifiScanThrottling(enabled: Boolean): CommandResult {
        val value = if (enabled) 1 else 0
        return ShellExecutor.exec("settings put global wifi_scan_throttle_enabled $value")
    }
}