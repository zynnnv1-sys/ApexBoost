package com.apexboost.domain.display

import com.apexboost.core.shizuku.CommandResult
import com.apexboost.core.shizuku.ShellExecutor

class GfxDisplayManager {

    /**
     * Mengatur resolusi layar kustom via WindowManager ADB
     * Contoh: "1080x2400" -> "720x1600" untuk FPS gaming 2x lebih lancar
     */
    suspend fun setCustomResolution(width: Int, height: Int): CommandResult {
        return ShellExecutor.exec("wm size ${width}x${height}")
    }

    /**
     * Reset resolusi layar kembali ke nilai bawaan pabrik
     */
    suspend fun resetResolution(): CommandResult {
        return ShellExecutor.exec("wm size reset")
    }

    /**
     * Mengatur DPI / Screen Density untuk sensitivitas bidikan layar
     */
    suspend fun setCustomDpi(dpi: Int): CommandResult {
        return ShellExecutor.exec("wm density $dpi")
    }

    /**
     * Reset DPI kembali ke nilai bawaan
     */
    suspend fun resetDpi(): CommandResult {
        return ShellExecutor.exec("wm density reset")
    }

    /**
     * Memaksa Refresh Rate layar (misal 90Hz, 120Hz, atau 144Hz)
     */
    suspend fun forceRefreshRate(hz: Float): CommandResult {
        val cmds = listOf(
            "settings put system min_refresh_rate $hz",
            "settings put system peak_refresh_rate $hz",
            "settings put global user_refresh_rate $hz"
        )
        return ShellExecutor.exec(cmds.joinToString(" && "))
    }
}