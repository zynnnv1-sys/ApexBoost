#!/bin/bash
echo "========================================================"
echo "   ApexBoost & Shizuku Quick ADB Starter (No-Root)"
echo "========================================================"
adb devices
echo "Mengaktifkan Shizuku Service..."
adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh
echo "Shizuku Berhasil Dinyalakan!"
