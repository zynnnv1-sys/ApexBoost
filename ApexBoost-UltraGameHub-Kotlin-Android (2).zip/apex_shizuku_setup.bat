@echo off
echo ========================================================
echo    ApexBoost & Shizuku Quick ADB Starter (No-Root)
echo ========================================================
echo Pastikan USB Debugging di HP Anda sudah AKTIF.
echo Menghubungkan ke perangkat ADB...
adb devices
echo Mengaktifkan Shizuku Service...
adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh
echo.
echo ========================================================
echo    Shizuku Berhasil Dinyalakan! Buka ApexBoost di HP.
echo ========================================================
pause
